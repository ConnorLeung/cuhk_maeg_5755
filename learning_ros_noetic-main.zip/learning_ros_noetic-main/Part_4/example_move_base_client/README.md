# example_move_base_client
Package to show how to build an action client of "move_base" for navigation commands

## Example usage
(optirun) `roslaunch mobot_urdf mobot_in_pen.launch`

`roslaunch mobot_nav_config mobot_startup_navstack.launch`

`rosrun example_move_base_client example_move_base_client`

    
