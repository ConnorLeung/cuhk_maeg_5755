# example_ros_msg

This package contains an example message definition and a corresponding node that uses the message definition. Details are covered in Part 1, Ch2 of the corresponding text.

    
