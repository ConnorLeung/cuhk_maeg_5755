//put joint-space planner weights here:
std::vector<double> g_planner_joint_weights{3,3,2,1,1,0.5};

