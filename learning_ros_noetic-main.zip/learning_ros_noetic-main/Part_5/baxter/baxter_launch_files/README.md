# baxter_launch_files

package to contain custom launch files for use with Baxter.
Includes yale_gripper_xform.launch, which is needed to define a grasp frame on the Yale gripper
relative to the right-arm tool flange.


    
