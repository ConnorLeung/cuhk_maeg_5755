# camera_calibration

`rosrun camera_calibration cameracalibrator.py --size 7x6 --square 0.02 image:=/simple_camera/image_raw camera:=/simple_camera`

for small checkerboard:
`rosrun camera_calibration cameracalibrator.py --size 7x6 --square 0.01 image:=/simple_camera/image_raw camera:=/simple_camera`
## Example usage

## Running tests/demos
    
