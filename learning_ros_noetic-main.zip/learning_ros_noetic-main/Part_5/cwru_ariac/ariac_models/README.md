# ariac_models
Models copied from https://bitbucket.org/osrf/ariac/

Could only spawn flange and pulley into Gazebo
part-bin has been modified to a simple prism

## Example usage
With Gazebo running, can run:
`roslaunch ariac_models add_bins.launch`
`roslaunch ariac_models add_parts.launch`

This will add parts bins and set some parts on them.
    
