# arm7dof
Directory for arm model with redundant kinematics, similar to the NASA satellite-servicer arm.
Model is in sub-package "arm7dof_model".  Arm forward and inverse kinematics library is in arm7dof_fk_ik.
Nested-loop joint controller is in "nested_loop_control".  Example NAC controller is in arm7dof_NAC_controller.

See README files in respective packages 




    
