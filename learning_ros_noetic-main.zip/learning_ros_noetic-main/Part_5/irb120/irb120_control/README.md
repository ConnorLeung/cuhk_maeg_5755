# irb120_control

package used only to specify controller gains for simulation of joint position controllers in Gazebo
Launch file loads controllers into Gazebo and starts "robot_state_publisher".  The launch file irb120_control.launch is included in irb120_description/irb120.launch
    
