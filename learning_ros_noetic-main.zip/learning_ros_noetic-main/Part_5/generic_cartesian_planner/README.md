# generic_cartesian_planner
General-purpose Cartesian-interpolation routines.  E.g. implements:
cartesian_path_planner_w_rot_interp( ) to interpolate Cartesian poses between
specified start and goal poses.  Then performs IK and graph-search solutions.
Object must be initialized with pointers to relevant FK/IK routines to override virtual routines.

## Example usage

## Running tests/demos
    
