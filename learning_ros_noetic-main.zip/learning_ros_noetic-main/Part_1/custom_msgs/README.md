# custom_msgs
shows example definition of a variable-length vector message.
Corresponding code for usage example is in package example_ros_msg
    
